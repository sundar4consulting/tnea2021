# Spring Boot Enquiry App

This is a Spring Boot application for handling enquiries.

## Prerequisites

- Java 8 or higher
- Maven

## Getting Started

1. Clone the repository:

   ```shell
   git clone https://github.com/your-username/spring-boot-enquiry-app.git
   ```

2. Navigate to the project directory:

   ```shell
   cd spring-boot-enquiry-app
   ```

3. Build the project:

   ```shell
   mvn clean install
   ```

4. Run the application:

   ```shell
   mvn spring-boot:run
   ```

5. The application will start running at `http://localhost:8080`.

## API Endpoints

### Submit Enquiry

- URL: `/api/enquiries`
- Method: POST
- Request Body:
  ```json
  {
    "name": "John Doe",
    "email": "johndoe@example.com",
    "message": "This is my enquiry message."
  }
  ```
- Response:
  ```json
  {
    "id": 1,
    "name": "John Doe",
    "email": "johndoe@example.com",
    "message": "This is my enquiry message."
  }
  ```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
```

Please note that you should replace `your-username` in the clone command with your actual GitHub username.