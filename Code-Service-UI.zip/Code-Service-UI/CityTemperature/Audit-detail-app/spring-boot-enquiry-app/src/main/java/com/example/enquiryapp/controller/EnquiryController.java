package com.example.enquiryapp.controller;

import com.example.enquiryapp.model.Enquiry;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/enquiry")
public class EnquiryController {

    @PostMapping("/submit")
    public ResponseEntity<String> submitEnquiry(@RequestBody Enquiry enquiry) {
        // Logic to process and save the enquiry details
        // You can access the enquiry properties like enquiry.getName(), enquiry.getEmail(), enquiry.getMessage()

        // Return a success response
        return ResponseEntity.status(HttpStatus.OK).body("Enquiry submitted successfully");
    }
}