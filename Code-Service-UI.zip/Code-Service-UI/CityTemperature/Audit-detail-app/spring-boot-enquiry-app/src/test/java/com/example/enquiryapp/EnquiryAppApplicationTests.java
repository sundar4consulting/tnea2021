package com.example.enquiryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnquiryAppApplicationTests {

    @Test
    void contextLoads() {
    }

}