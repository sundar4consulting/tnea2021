package com.example.myapp.controller;

import com.example.myapp.model.City;
import com.example.myapp.service.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/cities")
public class CityController {

    private final CityService cityService;

    @Autowired
    public CityController(CityService cityService) {
        this.cityService = cityService;
    }

    @GetMapping
    public List<City> getAllCities() {
        return cityService.getAllCities();
    }

    @GetMapping("/{id}")
    public City getCity(@PathVariable String id) {
        return cityService.getCityById(id);
    }
    
    @GetMapping("/{city}/weather")
    public Map<String, Object> getWeather(@PathVariable String city) {
        return cityService.getWeatherInfo(city);
    }

    @Value("${weather.api.key}")
    private String weatherApiKey;
}