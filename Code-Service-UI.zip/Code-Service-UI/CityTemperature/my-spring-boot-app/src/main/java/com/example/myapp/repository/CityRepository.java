package com.example.myapp.repository;

import com.example.myapp.model.City;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CityRepository extends MongoRepository<City, String> {
    // Add custom methods for retrieving city information from MongoDB
}