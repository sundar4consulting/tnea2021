package com.example.myapp.service;

import com.example.myapp.model.City;
import com.example.myapp.repository.CityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CityService {

    private final CityRepository cityRepository;

    @Autowired
    public CityService(CityRepository cityRepository) {
        this.cityRepository = cityRepository;
    }

    public List<City> getAllCities() {
        return cityRepository.findAll();
    }

    public City getCityById(String id) {
        return cityRepository.findById(id).orElse(null);
    }

    public City createCity(City city) {
        return cityRepository.save(city);
    }

    public City updateCity(String id, City city) {
        City existingCity = cityRepository.findById(id).orElse(null);
        if (existingCity != null) {
            existingCity.setName(city.getName());
            existingCity.setPopulation(city.getPopulation());
            existingCity.setCountry(city.getCountry());
            return cityRepository.save(existingCity);
        }
        return null;
    }

    public void deleteCity(String id) {
        cityRepository.deleteById(id);
    }
}