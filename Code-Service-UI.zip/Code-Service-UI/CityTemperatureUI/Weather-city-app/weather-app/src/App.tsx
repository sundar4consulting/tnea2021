import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import CurrentWeatherPage from './pages/CurrentWeatherPage';
import ForecastPage from './pages/ForecastPage';

function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={CurrentWeatherPage} />
        <Route path="/forecast" component={ForecastPage} />
      </Switch>
    </Router>
  );
}

export default App;