import React from 'react';

interface CityDropdownProps {
  cities: string[];
  onSelectCity: (city: string) => void;
}

const CityDropdown: React.FC<CityDropdownProps> = ({ cities, onSelectCity }) => {
  const handleCityChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedCity = event.target.value;
    onSelectCity(selectedCity);
  };

  return (
    <div>
      <label htmlFor="city">Select a city:</label>
      <select id="city" onChange={handleCityChange}>
        {cities.map((city) => (
          <option key={city} value={city}>
            {city}
          </option>
        ))}
      </select>
    </div>
  );
};

export default CityDropdown;