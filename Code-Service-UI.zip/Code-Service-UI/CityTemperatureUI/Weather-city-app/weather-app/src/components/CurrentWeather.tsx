import React from 'react';

interface CurrentWeatherProps {
  temperature: number;
  windSpeed: number;
  rainForecast: string;
}

const CurrentWeather: React.FC<CurrentWeatherProps> = ({ temperature, windSpeed, rainForecast }) => {
  return (
    <div>
      <h2>Current Weather</h2>
      <p>Temperature: {temperature}°C</p>
      <p>Wind Speed: {windSpeed} km/h</p>
      <p>Rain Forecast: {rainForecast}</p>
    </div>
  );
};

export default CurrentWeather;