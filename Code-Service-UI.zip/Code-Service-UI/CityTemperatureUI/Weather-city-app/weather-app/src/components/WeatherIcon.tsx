import React from 'react';

interface WeatherIconProps {
  weatherCondition: string;
}

const WeatherIcon: React.FC<WeatherIconProps> = ({ weatherCondition }) => {
  let iconUrl = '';

  // Map weather conditions to appropriate icon URLs
  switch (weatherCondition) {
    case 'sunny':
      iconUrl = '/assets/icons/sunny.png';
      break;
    case 'cloudy':
      iconUrl = '/assets/icons/cloudy.png';
      break;
    case 'rainy':
      iconUrl = '/assets/icons/rainy.png';
      break;
    default:
      iconUrl = '/assets/icons/default.png';
      break;
  }

  return <img src={iconUrl} alt="Weather Icon" />;
};

export default WeatherIcon;