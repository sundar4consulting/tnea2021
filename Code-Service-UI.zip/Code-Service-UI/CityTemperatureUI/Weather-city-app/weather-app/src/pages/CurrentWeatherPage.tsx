import React, { useState, useEffect } from 'react';
import CityDropdown from '../components/CityDropdown';
import CurrentWeather from '../components/CurrentWeather';
import { weatherService } from '../services/weatherService';

const CurrentWeatherPage: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState('');
  const [weatherData, setWeatherData] = useState<any>(null);

  useEffect(() => {
    if (selectedCity) {
      // Fetch weather data based on the selected city
      weatherService.fetchCurrentWeather(selectedCity)
        .then((data) => setWeatherData(data))
        .catch((error) => console.error(error));
    }
  }, [selectedCity]);

  const handleCityChange = (city: string) => {
    setSelectedCity(city);
  };

  return (
    <div>
      <h1>Current Weather</h1>
      <CityDropdown onChange={handleCityChange} />
      {weatherData && <CurrentWeather data={weatherData} />}
    </div>
  );
};

export default CurrentWeatherPage;