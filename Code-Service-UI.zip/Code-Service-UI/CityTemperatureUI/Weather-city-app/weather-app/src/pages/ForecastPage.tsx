import React, { useState, useEffect } from 'react';
import CityDropdown from '../components/CityDropdown';
import Forecast from '../components/Forecast';
import { weatherService } from '../services/weatherService';

const ForecastPage: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState('');
  const [forecastData, setForecastData] = useState([]);

  useEffect(() => {
    if (selectedCity) {
      // Fetch forecast data based on the selected city
      weatherService.getForecast(selectedCity)
        .then((data) => setForecastData(data))
        .catch((error) => console.error(error));
    }
  }, [selectedCity]);

  const handleCityChange = (city: string) => {
    setSelectedCity(city);
  };

  return (
    <div>
      <h1>Forecast</h1>
      <CityDropdown onChange={handleCityChange} />
      {forecastData.length > 0 ? (
        <Forecast data={forecastData} />
      ) : (
        <p>Please select a city to view the forecast.</p>
      )}
    </div>
  );
};

export default ForecastPage;