import React from 'react';
import WeatherIcon from '../components/WeatherIcon';

interface CurrentWeatherProps {
  temperature: number;
  windSpeed: number;
  rainForecast: string;
}

const CurrentWeather: React.FC<CurrentWeatherProps> = ({
  temperature,
  windSpeed,
  rainForecast,
}) => {
  return (
    <div>
      <h2>Current Weather</h2>
      <div>
        <span>Temperature: {temperature}°C</span>
      </div>
      <div>
        <span>Wind Speed: {windSpeed} km/h</span>
      </div>
      <div>
        <span>Rain Forecast: {rainForecast}</span>
      </div>
      <WeatherIcon icon="sun" />
    </div>
  );
};

export default CurrentWeather;