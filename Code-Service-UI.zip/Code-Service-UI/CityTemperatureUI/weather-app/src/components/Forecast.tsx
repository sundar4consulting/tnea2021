import React from 'react';
import WeatherIcon from '../components/WeatherIcon';

interface ForecastProps {
  forecastData: {
    date: string;
    temperature: number;
    windSpeed: number;
    rainForecast: string;
    weatherIcon: string;
  }[];
}

const Forecast: React.FC<ForecastProps> = ({ forecastData }) => {
  return (
    <div>
      <h2>Forecast</h2>
      {forecastData.map((data) => (
        <div key={data.date}>
          <h3>{data.date}</h3>
          <p>Temperature: {data.temperature}°C</p>
          <p>Wind Speed: {data.windSpeed} km/h</p>
          <p>Rain Forecast: {data.rainForecast}</p>
          <WeatherIcon icon={data.weatherIcon} />
        </div>
      ))}
    </div>
  );
};

export default Forecast;