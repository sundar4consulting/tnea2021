import React from 'react';

interface WeatherIconProps {
  icon: string;
  alt: string;
}

const WeatherIcon: React.FC<WeatherIconProps> = ({ icon, alt }) => {
  return <img src={icon} alt={alt} />;
};

export default WeatherIcon;