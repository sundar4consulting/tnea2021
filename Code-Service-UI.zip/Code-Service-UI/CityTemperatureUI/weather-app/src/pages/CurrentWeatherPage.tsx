import React from 'react';
import CurrentWeather from '../components/CurrentWeather';

const CurrentWeatherPage: React.FC = () => {
  return (
    <div>
      <h1>Current Weather</h1>
      <CurrentWeather />
    </div>
  );
};

export default CurrentWeatherPage;