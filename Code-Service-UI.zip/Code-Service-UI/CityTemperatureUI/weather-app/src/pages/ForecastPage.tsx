import React from 'react';
import Forecast from '../components/Forecast';

const ForecastPage: React.FC = () => {
  return (
    <div>
      <h1>Forecast</h1>
      <Forecast />
    </div>
  );
};

export default ForecastPage;